import 'package:flutter/material.dart';

class MyAppsss extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Editable List View Example'),
        ),
        body: EditableListView(),
      ),
    );
  }
}

class EditableListView extends StatefulWidget {
  @override
  _EditableListViewState createState() => _EditableListViewState();
}

class _EditableListViewState extends State<EditableListView> {
  List<bool> isEditing = List.generate(5, (index) => false);

  void toggleEdit(int index) {
    setState(() {
      isEditing[index] = !isEditing[index];
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: 5, // Number of containers
      itemBuilder: (BuildContext context, int index) {
        return Container(
          margin: EdgeInsets.all(10.0),
          padding: EdgeInsets.all(10.0),
          color: Colors.grey[300],
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Container $index'),
              ElevatedButton(
                onPressed: () {
                  toggleEdit(index);
                },
                child: Text(isEditing[index] ? 'OK' : 'Edit'),
              ),
            ],
          ),
        );
      },
    );
  }
}
