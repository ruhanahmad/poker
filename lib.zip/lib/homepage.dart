import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:poker/secondScreen.dart';

import 'controllers/data_controller.dart';



class MyApps extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    DataController _ =Get.put(DataController());
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('New Poker Game'),
          backgroundColor: Color(0xFF505771),
        ),
        backgroundColor: Color(0xFF505771),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal:8.0,vertical:50),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.edit, size: 40.0),
                   
                    SizedBox(width: 10.0),
                    Container(
                      width: 200.0,
                      child: 
                     TextField(
                      keyboardType: TextInputType.text,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 40.0,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      decoration: InputDecoration(
                        hintText: 'New Game',
                        hintStyle: TextStyle(
                          fontSize: 40.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        border: OutlineInputBorder(),
                      ),
                    ),
                    ),
                  ],
                ),
                Spacer(),
                Text(
                  'Players',
                  style: TextStyle(
                    fontSize: 24.0,
                    color: Colors.white
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal:14.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(icon:Icon(Icons.add),iconSize: 50,color: Colors.green,onPressed: (){
                           _.maxPlayers++;
                       
                        },),
                      SizedBox(width: 10.0),
                      Text(
                        '${_.maxPlayers}', // The initial value
                        style: TextStyle(
                          fontSize: 56.0,
                          color: Colors.white
                        ),
                      ),
                      SizedBox(width: 10.0),
                        IconButton(icon:Icon(Icons.remove),iconSize: 50,color: Colors.red,onPressed: (){
                           if (==0){
                           return;
                          }
                          else {
                  n--;
                        setState(() {
                          
                        });
                          }
                        },),
                     
                    ],
                  ),
                ),
                Spacer(),
                Text(
                  'Buy In',
                  style: TextStyle(
                    fontSize: 24.0,
                    color: Colors.green,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 60.0,
                      child: TextField(
                        keyboardType: TextInputType.number,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 36.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        // Implement logic to edit the number
                      },
                      style: ElevatedButton.styleFrom(
                        primary: Color(0xFFF0A637),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      child: Text(
                        'Edit',
                        style: TextStyle(fontSize: 20.0),
                      ),
                    ),
                  ],
                ),
                Spacer(),
                ElevatedButton(
                  onPressed: () {
         Get.to(()=> SecondScreen());
                  },
                  style: ElevatedButton.styleFrom(
                  primary: Color(0xFFF0A637),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30.0),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Next',
                          style: TextStyle(fontSize: 20.0),
                        ),
                        
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


