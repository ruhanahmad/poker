import 'package:flutter/material.dart';



class SecondScreen extends StatefulWidget {
  @override
  _SecondScreenState createState() => _SecondScreenState();
}

class _SecondScreenState extends State<SecondScreen> {
  List<Container> buyInsList = [];
  
  List<bool> isEditing =[] ;
  List<TextEditingController> oddTextControllers = [];
  List<TextEditingController> evenTextControllers = [];
  @override
  void dispose() {
    for (var controller in oddTextControllers) {
      controller.dispose();
    }
    for (var controller1 in evenTextControllers) {
      controller1.dispose();
    }
    super.dispose();
  }

  int n =0;
  

  void toggleEdit(int index) {
    setState(() {
      isEditing[index] = !isEditing[index];
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
          
            Text('Back', style: TextStyle(color: Colors.white)),
            Spacer(),
            TextButton.icon(
              onPressed: () {
                // Implement the logic to proceed to the next screen
              },
              icon: Icon(Icons.arrow_forward, color: Colors.white),
              label: Text('Start'),
            ),
          ],
        ),
        backgroundColor: Color(0xFF505771),
        elevation: 0, // No shadow under the app bar
      ),
      backgroundColor: Color(0xFF505771),
      body: Column(
        children: [
          Text('Starting Buy Ins', style: TextStyle(color: Colors.white, fontSize: 40.0)),
          SizedBox(height: 20,),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal:50.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('${DateTime.now().toString().split(' ')[0]}', style: TextStyle(color: Colors.grey,)),
                    Row(
                      children: [
                        Text('Buy In: ', style: TextStyle(color: Colors.grey,)),
                        // Replace '120' with the actual buy-in value from the previous screen
                        Text('120', style: TextStyle(color: Colors.grey,)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
           SizedBox(height: 30,),
          Container(
            height: 40,
            color: Color(0xFF626D94),
            child: Padding(
             padding: const EdgeInsets.symmetric(horizontal:50.0),
              child: Row(
                children: [
                  Text('Players', style: TextStyle(color: Colors.white)),
                  Spacer(),
                  Text('Buy Ins', style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
          ),
          Column(
            children: [



              Container(
                height: 500,
                width: MediaQuery.of(context).size.width,
                child: ListView.builder(
                  itemCount: n,
                  
                  itemBuilder:((context, index) {
                      List<bool> isEditing = List.generate(n, (index) => false);
                    oddTextControllers = List.generate(n, (_) => TextEditingController());
                                evenTextControllers = List.generate(n, (_) => TextEditingController());
              
              
                                return     
                                
                             isEditing[index] ?
                                 Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          padding: EdgeInsets.all(10.0),
                          decoration: BoxDecoration(
                            color: Color(0xFF626D94),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: 
                          
                          Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                   controller: oddTextControllers[index],
                                  decoration: InputDecoration(

                                    hintText: 'Name',
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width: 10.0),
                              DropdownButton<int>(
                                items: List.generate(200, (index) => DropdownMenuItem<int>(
                                  value: index + 1,
                                  child: Text((index + 1).toString()),
                                )).toList(),
                                onChanged: (value) {
                                   
                                  // Implement logic to handle dropdown selection
                                },
                                underline: Container(),
                                value: 1,
                              ),
                              SizedBox(width: 10.0),
                              Expanded(
                                child: TextField(
                                       controller: evenTextControllers[index],
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: 'Amount',
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                  ),
                                ),
                              ),
                              ElevatedButton(
                                onPressed: () {
                       
                                 toggleEdit(index);
                                  print(index);
                                  // Implement logic for the 'OK' button
                               
                                },
                                style: ElevatedButton.styleFrom(
                                  primary: Color(0xFF773BE0),
                                ),
                                child: Text(isEditing[index] ? 'OK' : 'Edit'),
                              ),
                            ],
                          ),
                        )
                        :
         Container(
                          margin: EdgeInsets.symmetric(vertical: 5.0),
                          padding: EdgeInsets.all(10.0),
                          decoration: BoxDecoration(
                            color: Color(0xFF626D94),
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                          child: 
                          
                          Row(
                            children: [
                              Expanded(
                                child: TextFormField(
                                   controller: oddTextControllers[index],
                                  decoration: InputDecoration(

                                    hintText: 'Namee',
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width: 10.0),
                              DropdownButton<int>(
                                items: List.generate(200, (index) => DropdownMenuItem<int>(
                                  value: index + 1,
                                  child: Text((index + 1).toString()),
                                )).toList(),
                                onChanged: (value) {
                                   
                                  // Implement logic to handle dropdown selection
                                },
                                underline: Container(),
                                value: 1,
                              ),
                              SizedBox(width: 10.0),
                              Expanded(
                                child: TextField(
                                       controller: evenTextControllers[index],
                                  keyboardType: TextInputType.number,
                                  decoration: InputDecoration(
                                    hintText: 'Amount',
                                    fillColor: Colors.white,
                                    filled: true,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                  ),
                                ),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                       toggleEdit(index);
                                  print(index);
                                  // Implement logic for the 'OK' button
                                  // setState(() {
                                  //   isEditing = true;
                                  // });
                                },
                                style: ElevatedButton.styleFrom(
                                  primary: Color(0xFF773BE0),
                                ),
                                child: Text('OK'),
                              ),
                            ],
                          ),
                        );
                })),
              ),
                // ...buyInsList,
               
              ElevatedButton(
                onPressed: () {
                  // Implement logic to add a new container
                  setState(() {
                    // buyInsList.add(
                  n++;
                    // );
                  });
                },
                style: ElevatedButton.styleFrom(primary: Color(0xFF7D37F0)),
                child: Text('Add'),
              ),
      //        ...buyInsList,
            ],
          ),
        ],
      ),
    );
  }
}
